// src/components/Login.js
import React from 'react';

const Login = () => {
  // Add your login logic here
  return (
    <div>
      <h2>Login Page</h2>
    </div>
  );
};

export default Login;
